public class MainMenu {
    
    public void btProductCategoryAction() {
        Main.getInstance().openProductAndCategories();
    }
    
    public void btStockAction() {
        Main.getInstance().openStock();
    }
    
}
